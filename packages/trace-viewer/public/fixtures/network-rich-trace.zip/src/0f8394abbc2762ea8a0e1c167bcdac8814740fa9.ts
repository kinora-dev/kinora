
import { expect, test } from '@playwright/test'

test('rich network activity', async ({ page }) => {
  await page.route('**/api/cart', route => route.fulfill({
    contentType: 'application/json',
    headers: { 'x-demo': 'cart' },
    body: JSON.stringify({ plan: 'Pro', seats: 1 }),
  }))
  await page.route('**/api/checkout', async (route) => {
    const post = route.request().postDataJSON()
    await route.fulfill({
      contentType: 'application/json',
      status: 201,
      headers: { 'x-demo': 'checkout' },
      body: JSON.stringify({ ok: true, email: post.email }),
    })
  })
  await page.route('**/api/missing', route => route.fulfill({ status: 404, contentType: 'application/json', body: JSON.stringify({ error: 'not_found' }) }))
  await page.route('**/api/error', route => route.fulfill({ status: 500, contentType: 'text/plain', body: 'server exploded' }))
  await page.setContent('<button id="load">Load network</button><pre id="out"></pre><script>document.getElementById("load").addEventListener("click",async()=>{const cart=await fetch("https://demo.kinora.dev/api/cart").then(r=>r.json());const checkout=await fetch("https://demo.kinora.dev/api/checkout",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({email:"alex@example.com",plan:cart.plan})}).then(r=>r.json());await fetch("https://demo.kinora.dev/api/missing");await fetch("https://demo.kinora.dev/api/error");console.log("network checkout",checkout.email);document.getElementById("out").textContent=checkout.email})<\/script>')
  await page.getByRole('button', { name: 'Load network' }).click()
  await expect(page.locator('#out')).toHaveText('alex@example.com')
})

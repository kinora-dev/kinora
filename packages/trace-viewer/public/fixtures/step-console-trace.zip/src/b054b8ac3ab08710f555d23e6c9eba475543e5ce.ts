
import { test } from '@playwright/test'

test('step console', async ({ page }) => {
  await page.setContent('<button onclick="console.log(&quot;clicked in step&quot;)">Go</button>')
  await test.step('checkout step', async () => {
    await page.getByRole('button', { name: 'Go' }).click()
    await page.evaluate(() => console.warn('warned in step'))
    console.log('runner line in step')
  })
})


import { expect, test } from '@playwright/test'

test('console formatting', async ({ page }) => {
  console.log('\x1b[32mrunner ready\x1b[39m')
  console.error('runner warning on stderr')
  await page.setContent('<button id="go">Go</button><script>document.getElementById("go").onclick = () => { console.log("%cstyled%c plain %s", "color: rgb(255, 0, 0); font-weight: bold", "", "value"); for (let i = 0; i < 3; i++) console.log("repeated message"); setTimeout(() => { throw new Error("boom from page") }, 0); setTimeout(() => { document.title = "done" }, 50) }<\/script>')
  await page.getByRole('button', { name: 'Go' }).click()
  await expect(page).toHaveTitle('done')
})

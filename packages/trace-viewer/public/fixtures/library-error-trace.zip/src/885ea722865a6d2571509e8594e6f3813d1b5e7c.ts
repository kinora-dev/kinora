
import { test } from '@playwright/test'

test.use({ trace: 'off' })

test('library error', async ({ browser }, testInfo) => {
  const context = await browser.newContext()
  await context.tracing.start({ snapshots: true, sources: true })
  const page = await context.newPage()
  await page.setContent('<main><h1>Checkout</h1><button>Add to cart</button></main>')
  await page.getByRole('button', { name: 'Pay now' }).click({ timeout: 500 }).catch(() => {})
  await context.tracing.stop({ path: testInfo.outputPath('trace.zip') })
  await context.close()
})

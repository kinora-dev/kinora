
import { expect, test } from '@playwright/test'

test('completes a purchase', async ({ page }) => {
  await page.setContent('<main><h1>Checkout</h1><button>Add to cart</button></main>')
  await expect(page.getByRole('button', { name: 'Pay now' })).toBeVisible({ timeout: 1500 })
})

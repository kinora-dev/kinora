
import { expect, test } from '@playwright/test'

// The test runner's trace option cannot record ARIA snapshots, so this test traces its own context.
test.use({ trace: 'off' })

test('aria checkout', async ({ browser }, testInfo) => {
  const context = await browser.newContext()
  await context.tracing.start({ snapshots: { aria: true, screen: true }, sources: true })
  const page = await context.newPage()
  await page.setContent([
    '<main>',
    '<h1 id="title">Checkout</h1>',
    '<label>Customer email <input id="customer"></label>',
    '<button id="complete">Complete checkout</button>',
    '</main>',
    '<script>document.getElementById("complete").onclick = () => { document.getElementById("title").textContent = "Order complete" }</script>',
  ].join(''))
  await page.getByLabel('Customer email').fill('alex@example.com')
  await page.getByRole('button', { name: 'Complete checkout' }).click()
  await expect(page.getByRole('heading', { level: 1 })).toHaveText('Order complete')
  await context.tracing.stop({ path: testInfo.outputPath('trace.zip') })
  await context.close()
})


import { expect, test } from '@playwright/test'

test('popup receipt support', async ({ page, context }) => {
  await context.route('**/receipt.html', route => route.fulfill({
    contentType: 'text/html',
    body: '<!doctype html><title>Receipt</title><main><h1>Receipt popup</h1><button id="close">Close receipt</button><script>console.log("popup receipt opened")<\/script></main>',
  }))
  await page.setContent('<button id="open">Open receipt</button><script>document.getElementById("open").addEventListener("click",()=>window.open("https://demo.kinora.dev/receipt.html","receipt"))<\/script>', { baseURL: 'https://demo.kinora.dev' })
  const popupPromise = page.waitForEvent('popup')
  await page.getByRole('button', { name: 'Open receipt' }).click()
  const popup = await popupPromise
  await popup.waitForLoadState('domcontentloaded')
  await expect(popup.getByRole('heading', { name: 'Receipt popup' })).toBeVisible()
  await popup.getByRole('button', { name: 'Close receipt' }).click()
})


import { expect, test } from '@playwright/test'

test('iframe checkout support', async ({ page }) => {
  await page.setContent([
    '<main>',
    '<h1>Iframe payment shell</h1>',
    '<iframe title="Payment frame" srcdoc="<form><label>Card holder <input id=cardholder placeholder=Cardholder></label><button id=pay type=button>Pay invoice</button><p id=status>Waiting</p><script>document.getElementById(&quot;pay&quot;).addEventListener(&quot;click&quot;,()=>{document.getElementById(&quot;status&quot;).textContent=&quot;Paid inside iframe&quot;;console.log(&quot;iframe payment submitted&quot;)})<\/script></form>"></iframe>',
    '</main>',
  ].join(''))
  const frame = page.frameLocator('iframe[title="Payment frame"]')
  await frame.locator('#cardholder').fill('Alex Example')
  await frame.getByRole('button', { name: 'Pay invoice' }).click()
  await expect(frame.getByText('Paid inside iframe')).toBeVisible()
})


import { expect, test } from '@playwright/test'

test('plan card matches its screenshot', async ({ page }) => {
  await page.setContent('<div id="card" style="width:240px;height:120px;font:16px sans-serif;padding:16px;box-sizing:border-box;background:#fff"><b>Kinora Pro</b><p style="color:#2563eb">$29 / month</p></div>')
  await expect(page.locator('#card')).toHaveScreenshot('plan-card.png')
})

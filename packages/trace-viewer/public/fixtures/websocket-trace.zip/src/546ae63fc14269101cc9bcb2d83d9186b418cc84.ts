
import { Buffer } from 'node:buffer'
import { createHash } from 'node:crypto'
import { createServer } from 'node:http'
import { expect, test } from '@playwright/test'

function frame(opcode, payload) {
  const body = Buffer.from(payload)
  return Buffer.concat([Buffer.from([0x80 | opcode, body.length]), body])
}

test('live price feed', async ({ page }) => {
  const server = createServer()
  server.on('upgrade', (req, socket) => {
    const accept = createHash('sha1').update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n')
    socket.write(frame(1, 'welcome'))
    socket.on('data', (buf) => {
      const opcode = buf[0] & 0x0F
      const mask = buf.subarray(2, 6)
      const data = Buffer.from(buf.subarray(6, 6 + (buf[1] & 0x7F)).map((b, i) => b ^ mask[i % 4]))
      if (opcode === 8) {
        socket.end(frame(8, ''))
        return
      }
      // The browser answers our ping with a pong: only text frames get a reply.
      if (opcode !== 1)
        return
      socket.write(frame(1, JSON.stringify({ plan: data.toString(), price: 29, currency: 'USD' })))
      socket.write(frame(2, [0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x01]))
      socket.write(frame(9, 'ping'))
    })
  })
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
  const { port } = server.address()

  await page.setContent('<main><h1>Prices</h1><ul id="log"></ul></main>')
  await page.evaluate(url => new Promise((resolve) => {
    const ws = new WebSocket(url)
    let received = 0
    ws.onmessage = () => {
      if (++received === 3) {
        ws.close()
        resolve()
      }
    }
    ws.onopen = () => ws.send('pro')
  }), 'ws://127.0.0.1:' + port + '/prices')
  await expect(page.getByRole('heading', { name: 'Prices' })).toBeVisible()
  server.close()
})
